<link rel="stylesheet" href="/PETVET/public/css/admin/styles.css">
<div class="main-content">
  <h1>Lost & Found</h1>
  <p>Coming soon...</p>
</div>
