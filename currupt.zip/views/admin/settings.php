<link rel="stylesheet" href="/PETVET/public/css/admin/styles.css">
<div class="main-content">
  <h1>Admin Settings</h1>
  <p>Configure system-level settings.</p>
</div>
